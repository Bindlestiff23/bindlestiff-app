import React from 'react';
import './App.css';
import BindleverseHeader from './components/BindleverseHeader';

function App() {
  return (
    <div className="App">
      <BindleverseHeader />
    </div>
  );
}

export default App;
